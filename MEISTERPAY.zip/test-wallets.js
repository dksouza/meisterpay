require('dotenv').config({ path: '.env.local' });
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function test() {
  const { data, error } = await supabase.from('checkouts').select('id, enable_wallets, title').limit(5);
  console.log("Checkouts:", data);
  console.log("Error:", error);
}
test();
